package com.example.smartfileorganizer;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import java.io.File;
import java.util.List;

public class MoveFolderDialogFragment extends DialogFragment {
    public interface OnFolderSelectedListener {
        void onFolderSelected(File folder);
    }

    private final List<File> folders;
    private final OnFolderSelectedListener listener;
    private int selectedPosition = -1;

    public MoveFolderDialogFragment(List<File> folders, OnFolderSelectedListener listener) {
        this.folders = folders;
        this.listener = listener;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View view = inflater.inflate(R.layout.move_folder_dialog, null);

        ListView foldersList = view.findViewById(R.id.foldersList);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getContext(),
                android.R.layout.simple_list_item_1,
                getFolderNames()) {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull android.view.ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                v.setBackgroundColor(getResources().getColor(
                        position == selectedPosition ? R.color.dialog_selected_bg : R.color.dialog_item_bg
                ));
                ((android.widget.TextView) v).setTextColor(getResources().getColor(R.color.dialog_item_text));
                return v;
            }
        };
        foldersList.setAdapter(adapter);

        foldersList.setOnItemClickListener((AdapterView<?> parent, View v, int pos, long id) -> {
            selectedPosition = pos;
            adapter.notifyDataSetChanged();
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.MoveDialogTheme);
        builder.setView(view)
                .setPositiveButton("نقل", (dialog, which) -> {
                    if (selectedPosition != -1) {
                        listener.onFolderSelected(folders.get(selectedPosition));
                    }
                })
                .setNegativeButton("إلغاء", null);

        return builder.create();
    }

    private String[] getFolderNames() {
        String[] arr = new String[folders.size()];
        for (int i = 0; i < folders.size(); i++) {
            arr[i] = folders.get(i).getName();
        }
        return arr;
    }
}
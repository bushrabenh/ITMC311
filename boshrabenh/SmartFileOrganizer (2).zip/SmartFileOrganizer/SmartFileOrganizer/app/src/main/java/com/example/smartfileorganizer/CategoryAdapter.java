package com.example.smartfileorganizer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder> {

    public interface OnActionClickListener {
        void onDeleteClicked(CategoryModel category);
        void onMoveClicked(CategoryModel category);
    }

    private List<CategoryModel> categories;
    private Context context;
    private OnActionClickListener listener;

    public CategoryAdapter(Context context, List<CategoryModel> categories, OnActionClickListener listener) {
        this.context = context;
        this.categories = categories;
        this.listener = listener;
    }

    @Override
    public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category_card, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CategoryViewHolder holder, int position) {
        CategoryModel model = categories.get(position);

        holder.categoryTitle.setText(model.getTitle());
        holder.categoryStats.setText("عدد: " + model.getFileCount() + " | الحجم: " + android.text.format.Formatter.formatFileSize(context, model.getTotalSize()));
        holder.categoryIcon.setImageResource(model.getIconResId());
        holder.categoryIcon.setColorFilter(ContextCompat.getColor(context, model.getIconColorResId()));
        holder.cardView.setCardBackgroundColor(ContextCompat.getColor(context, model.getCardColorResId()));

        holder.deleteBtn.setOnClickListener(v -> {
            if (listener != null) listener.onDeleteClicked(model);
        });

        holder.moveBtn.setOnClickListener(v -> {
            if (listener != null) listener.onMoveClicked(model);
        });

        // لا تخفي البطاقة حتى لو العدد صفر!
        holder.itemView.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        ImageView categoryIcon;
        TextView categoryTitle, categoryStats;
        ImageButton deleteBtn, moveBtn;
        com.google.android.material.card.MaterialCardView cardView;

        CategoryViewHolder(View itemView) {
            super(itemView);
            cardView = (com.google.android.material.card.MaterialCardView) itemView;
            categoryIcon = itemView.findViewById(R.id.categoryIcon);
            categoryTitle = itemView.findViewById(R.id.categoryTitle);
            categoryStats = itemView.findViewById(R.id.categoryStats);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);
            moveBtn = itemView.findViewById(R.id.moveBtn);
        }
    }
}
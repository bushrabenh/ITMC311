package com.example.smartfileorganizer;



import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View; // جديد: لاستخدام View.VISIBLE/GONE

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList; // جديد: لاستخدام ArrayList
import java.util.List;

public class RecommendationsActivity extends AppCompatActivity implements FileAdapter.OnFileActionListener {

    private TextView noRecommendationsText;
    private RecyclerView recommendationsRecyclerView;
    private FileAdapter fileAdapter;
    private List<File> largeFiles; // قائمة الملفات الكبيرة التي تم تمريرها

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommendations);

        noRecommendationsText = findViewById(R.id.noRecommendationsText);
        recommendationsRecyclerView = findViewById(R.id.recommendationsRecyclerView);

        // استلام قائمة الملفات الكبيرة من Intent
        // يجب التحقق من أنها ليست null وتصنيفها كـ ArrayList أو List<File>
        if (getIntent().hasExtra("largeFiles")) {
            // نستخدم ArrayList لأنها قابلة للتسلسل (Serializable)
            largeFiles = (List<File>) getIntent().getSerializableExtra("largeFiles");
            if (largeFiles == null) {
                largeFiles = new ArrayList<>(); // تأكد من تهيئتها كقائمة فارغة إذا كانت null
            }
        } else {
            largeFiles = new ArrayList<>(); // إذا لم يتم تمرير أي شيء، فستكون قائمة فارغة
        }

        if (largeFiles.isEmpty()) {
            noRecommendationsText.setVisibility(View.VISIBLE);
            recommendationsRecyclerView.setVisibility(View.GONE);
        } else {
            noRecommendationsText.setVisibility(View.GONE);
            recommendationsRecyclerView.setVisibility(View.VISIBLE);

            // تهيئة RecyclerView
            recommendationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            fileAdapter = new FileAdapter(this, largeFiles, this); // تمرير 'this' كـ OnFileActionListener
            recommendationsRecyclerView.setAdapter(fileAdapter);
        }
    }

    // =============================================================================================
    // معالجة أحداث من FileAdapter (مثل النقر على زر الحذف)
    // =============================================================================================

    @Override
    public void onDeleteClick(File file, int position) {
        // تأكيد الحذف من المستخدم
        new AlertDialog.Builder(this, R.style.AlertDialogTheme) // يمكنك إنشاء ثيم خاص للتحذير
                .setTitle("تأكيد الحذف")
                .setMessage("هل أنت متأكد من رغبتك في حذف هذا الملف؟\n\n" + file.getName())
                .setPositiveButton("حذف", (dialog, which) -> {
                    // محاولة حذف الملف
                    if (file.exists()) {
                        if (file.delete()) {
                            Toast.makeText(this, "تم حذف الملف بنجاح: " + file.getName(), Toast.LENGTH_SHORT).show();
                            fileAdapter.removeFileAt(position); // إزالة العنصر من القائمة في الـ Adapter
                            // قد تحتاج أيضًا إلى إعادة تحديث شاشة MainActivity بعد الحذف
                            // يمكنك استخدام startActivityForResult() في MainActivity و onActivityResult() هنا
                        } else {
                            Toast.makeText(this, "فشل حذف الملف: " + file.getName() + "\n(قد لا يكون لديك إذن الكتابة)", Toast.LENGTH_LONG).show();
                            Log.e("FileDelete", "Failed to delete file: " + file.getAbsolutePath());
                        }
                    } else {
                        Toast.makeText(this, "الملف غير موجود بالفعل.", Toast.LENGTH_SHORT).show();
                        fileAdapter.removeFileAt(position); // إزالته من القائمة إذا لم يكن موجودًا
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }
}

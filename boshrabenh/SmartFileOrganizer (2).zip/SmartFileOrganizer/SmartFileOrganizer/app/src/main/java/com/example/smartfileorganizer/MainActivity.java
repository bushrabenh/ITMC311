package com.example.smartfileorganizer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    TextView totalText, freeText, usagePercentage;
    ProgressBar storageProgressBar;
    RecyclerView categoriesRecyclerView;
    ProgressBar loadingProgress;
    ImageView cleaningAnimation;

    StorageManager sm;
    long totalSpace = 0;
    long freeSpace = 0;

    private List<File> largeFilesList = new ArrayList<>();

    private static final int REQUEST_NOTIFICATION_PERMISSION = 101;
    private static final int REQUEST_ALL_FILES_ACCESS = 200;
    private static final int REQUEST_CODE_PICK_DIRECTORY = 300;

    private List<CategoryModel> categoryModels = new ArrayList<>();
    private Map<CategoryModel.CategoryType, List<File>> categoryFilesMap = new HashMap<>();
    private Map<CategoryModel.CategoryType, Long> categorySizeMap = new HashMap<>();

    private CategoryAdapter adapter;

    // لتخزين التصنيف مؤقتًا أثناء النقل
    private CategoryModel pendingMoveCategory;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        totalText = findViewById(R.id.totalSpace);
        freeText = findViewById(R.id.freeSpace);
        usagePercentage = findViewById(R.id.usagePercentage);
        storageProgressBar = findViewById(R.id.storageProgressBar);
        categoriesRecyclerView = findViewById(R.id.categoriesRecyclerView);
        loadingProgress = findViewById(R.id.loadingProgress);
        cleaningAnimation = findViewById(R.id.cleaningAnimation);

        sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);

        adapter = new CategoryAdapter(this, categoryModels, new CategoryAdapter.OnActionClickListener() {
            @Override
            public void onDeleteClicked(CategoryModel category) {
                showCleaningAnimation();
                List<File> files = category.getFiles();
                int deletedCount = 0;
                for (File file : files) {
                    if (file.exists()) {
                        if (file.delete()) {
                            deletedCount++;
                        }
                    }
                }
                Toast.makeText(MainActivity.this, "تم حذف " + deletedCount + " ملف من تصنيف " + category.getTitle(), Toast.LENGTH_SHORT).show();
                initializeStorageOperations();
            }

            @Override
            public void onMoveClicked(CategoryModel category) {
                // بدلاً من نقل الملفات مباشرة، افتح نافذة اختيار مجلد
                pendingMoveCategory = category;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                startActivityForResult(intent, REQUEST_CODE_PICK_DIRECTORY);
            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        categoriesRecyclerView.setLayoutManager(layoutManager);
        categoriesRecyclerView.setAdapter(adapter);

        checkAndRequestPermissions();

        View recommendationsBtn = findViewById(R.id.recommendationsButton);
        if (recommendationsBtn != null) {
            recommendationsBtn.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, RecommendationsActivity.class);
                intent.putExtra("largeFiles", (Serializable) largeFilesList);
                startActivity(intent);
            });
        }
    }

    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATION_PERMISSION);
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivityForResult(intent, REQUEST_ALL_FILES_ACCESS);
                Toast.makeText(this, "يرجى منح إذن 'الوصول إلى جميع الملفات' للتطبيق", Toast.LENGTH_LONG).show();
            } else {
                initializeStorageOperations();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_ALL_FILES_ACCESS);
            } else {
                initializeStorageOperations();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATION_PERMISSION) {
            // إشعار فقط
        } else if (requestCode == REQUEST_ALL_FILES_ACCESS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeStorageOperations();
            } else {
                Toast.makeText(this, "لا يمكن قراءة الملفات بدون إذن التخزين", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ALL_FILES_ACCESS) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    initializeStorageOperations();
                } else {
                    Toast.makeText(this, "هذا التطبيق يتطلب إذن 'الوصول إلى جميع الملفات' ليعمل بشكل صحيح.", Toast.LENGTH_LONG).show();
                }
            }
        } else if (requestCode == REQUEST_CODE_PICK_DIRECTORY && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null && pendingMoveCategory != null) {
                moveFilesToDirectory(treeUri, pendingMoveCategory);
                pendingMoveCategory = null;
            }
        }
    }

    private void moveFilesToDirectory(Uri treeUri, CategoryModel category) {
        showCleaningAnimation();
        int movedCount = 0;
        List<File> files = category.getFiles();

        for (File file : files) {
            try {
                String fileName = file.getName();
                // إنشاء ملف جديد في المجلد الوجهة عبر SAF
                Uri destUri = DocumentsContract.createDocument(getContentResolver(), treeUri,
                        "application/octet-stream", fileName);

                if (destUri != null) {
                    try (InputStream in = new FileInputStream(file);
                         OutputStream out = getContentResolver().openOutputStream(destUri)) {
                        byte[] buffer = new byte[4096];
                        int read;
                        while ((read = in.read(buffer)) != -1) {
                            out.write(buffer, 0, read);
                        }
                        out.flush();
                    }
                    // حذف الملف الأصلي بعد النقل
                    file.delete();
                    movedCount++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Toast.makeText(this, "تم نقل " + movedCount + " ملف إلى المجلد الذي اخترته", Toast.LENGTH_SHORT).show();
        initializeStorageOperations();
    }

    private void initializeStorageOperations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Toast.makeText(this, "لا يمكن قراءة الملفات بدون إذن 'الوصول إلى جميع الملفات'", Toast.LENGTH_LONG).show();
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "لا يمكن قراءة الملفات بدون إذن التخزين", Toast.LENGTH_LONG).show();
                return;
            }
        }

        runOnUiThread(() -> loadingProgress.setVisibility(View.VISIBLE));

        new Thread(() -> {
            largeFilesList.clear();
            categoryFilesMap.clear();
            categorySizeMap.clear();

            File path = Environment.getExternalStorageDirectory();
            if (path != null && path.exists() && path.isDirectory() && path.canRead()) {
                totalSpace = path.getTotalSpace();
                freeSpace = path.getFreeSpace();

                runOnUiThread(() -> {
                    totalText.setText("المساحة الكلية: " + formatSize(totalSpace));
                    freeText.setText("المساحة الفارغة: " + formatSize(freeSpace));
                    if (totalSpace > 0) {
                        long usedSpace = totalSpace - freeSpace;
                        int percentage = (int) ((usedSpace * 100) / totalSpace);
                        storageProgressBar.setProgress(percentage);
                        usagePercentage.setText(percentage + "% مستخدم");
                    } else {
                        storageProgressBar.setProgress(0);
                        usagePercentage.setText("0% مستخدم");
                    }
                });

                checkStorageSpace();

                scanUserFolders();

                runOnUiThread(() -> {
                    setupCategoryModels();
                    loadingProgress.setVisibility(View.GONE);
                });

            } else {
                runOnUiThread(() -> {
                    Toast.makeText(this, "فشل الوصول إلى التخزين. تأكد من منح الأذونات.", Toast.LENGTH_LONG).show();
                    loadingProgress.setVisibility(View.GONE);
                });
            }
        }).start();
    }

    // هنا التعديل الرئيسي: المسح يبدأ من الجذر
    private void scanUserFolders() {
        String[] imageExt = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".heic"};
        String[] videoExt = {".mp4", ".mkv", ".avi", ".mov", ".webm", ".3gp", ".flv"};
        String[] docExt = {".pdf", ".docx", ".doc", ".txt", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".rtf", ".csv"};
        String[] audioExt = {".mp3", ".wav", ".ogg", ".flac", ".aac", ".m4a"};
        String[] archiveExt = {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"};
        String[] apkExt = {".apk"};

        for (CategoryModel.CategoryType type : CategoryModel.CategoryType.values()) {
            categoryFilesMap.put(type, new ArrayList<>());
            categorySizeMap.put(type, 0L);
        }

        // لمسح جميع الملفات في التخزين الخارجي
        File root = Environment.getExternalStorageDirectory();
        scanRecursive(root, imageExt, videoExt, docExt, audioExt, archiveExt, apkExt);
    }

    private void scanRecursive(File dir, String[] img, String[] vid, String[] doc,
                               String[] audio, String[] archive, String[] apk) {
        if (dir == null || !dir.isDirectory() || !dir.canRead()) {
            return;
        }
        File[] files = dir.listFiles();
        if (files == null) {
            return;
        }
        for (File file : files) {
            String fileName = file.getName();
            if (fileName.startsWith(".")) continue;

            if (file.isFile()) {
                if (file.length() > 50 * 1024 * 1024) {
                    largeFilesList.add(file);
                }
                String lowerCaseName = fileName.toLowerCase();
                if (endsWithAny(lowerCaseName, img)) {
                    addToCategory(CategoryModel.CategoryType.IMAGE, file);
                } else if (endsWithAny(lowerCaseName, vid)) {
                    addToCategory(CategoryModel.CategoryType.VIDEO, file);
                } else if (endsWithAny(lowerCaseName, doc)) {
                    addToCategory(CategoryModel.CategoryType.DOCUMENT, file);
                } else if (endsWithAny(lowerCaseName, audio)) {
                    addToCategory(CategoryModel.CategoryType.AUDIO, file);
                } else if (endsWithAny(lowerCaseName, archive)) {
                    addToCategory(CategoryModel.CategoryType.ARCHIVE, file);
                } else if (endsWithAny(lowerCaseName, apk)) {
                    addToCategory(CategoryModel.CategoryType.APK, file);
                } else {
                    addToCategory(CategoryModel.CategoryType.OTHER, file);
                }
            } else if (file.isDirectory()) {
                scanRecursive(file, img, vid, doc, audio, archive, apk);
            }
        }
    }

    private void addToCategory(CategoryModel.CategoryType type, File file) {
        categoryFilesMap.get(type).add(file);
        categorySizeMap.put(type, categorySizeMap.get(type) + file.length());
    }

    private boolean endsWithAny(String name, String[] extensions) {
        for (String ext : extensions) {
            if (name.endsWith(ext)) return true;
        }
        return false;
    }

    private void setupCategoryModels() {
        categoryModels.clear();

        categoryModels.add(new CategoryModel(
                CategoryModel.CategoryType.IMAGE,
                "الصور",
                R.drawable.ic_image,
                R.color.category_card_bg_image,
                R.color.category_icon_tint_image,
                categoryFilesMap.get(CategoryModel.CategoryType.IMAGE).size(),
                categorySizeMap.get(CategoryModel.CategoryType.IMAGE),
                categoryFilesMap.get(CategoryModel.CategoryType.IMAGE)
        ));
        categoryModels.add(new CategoryModel(
                CategoryModel.CategoryType.VIDEO,
                "الفيديو",
                R.drawable.outline_audio_video_receiver_24,
                R.color.category_card_bg_video,
                R.color.category_icon_tint_video,
                categoryFilesMap.get(CategoryModel.CategoryType.VIDEO).size(),
                categorySizeMap.get(CategoryModel.CategoryType.VIDEO),
                categoryFilesMap.get(CategoryModel.CategoryType.VIDEO)
        ));
        categoryModels.add(new CategoryModel(
                CategoryModel.CategoryType.DOCUMENT,
                "المستندات",
                R.drawable.outline_apk_document_24,
                R.color.category_card_bg_doc,
                R.color.category_icon_tint_doc,
                categoryFilesMap.get(CategoryModel.CategoryType.DOCUMENT).size(),
                categorySizeMap.get(CategoryModel.CategoryType.DOCUMENT),
                categoryFilesMap.get(CategoryModel.CategoryType.DOCUMENT)
        ));
        categoryModels.add(new CategoryModel(
                CategoryModel.CategoryType.AUDIO,
                "الصوتيات",
                R.drawable.outline_adaptive_audio_mic_24,
                R.color.category_card_bg_audio,
                R.color.category_icon_tint_audio,
                categoryFilesMap.get(CategoryModel.CategoryType.AUDIO).size(),
                categorySizeMap.get(CategoryModel.CategoryType.AUDIO),
                categoryFilesMap.get(CategoryModel.CategoryType.AUDIO)
        ));
        categoryModels.add(new CategoryModel(
                CategoryModel.CategoryType.ARCHIVE,
                "الأرشيفات",
                R.drawable.ic_archive,
                R.color.category_card_bg_archive,
                R.color.category_icon_tint_archive,
                categoryFilesMap.get(CategoryModel.CategoryType.ARCHIVE).size(),
                categorySizeMap.get(CategoryModel.CategoryType.ARCHIVE),
                categoryFilesMap.get(CategoryModel.CategoryType.ARCHIVE)
        ));
        categoryModels.add(new CategoryModel(
                CategoryModel.CategoryType.APK,
                "التطبيقات",
                R.drawable.outline_apk_install_24,
                R.color.category_card_bg_apk,
                R.color.category_icon_tint_apk,
                categoryFilesMap.get(CategoryModel.CategoryType.APK).size(),
                categorySizeMap.get(CategoryModel.CategoryType.APK),
                categoryFilesMap.get(CategoryModel.CategoryType.APK)
        ));
        categoryModels.add(new CategoryModel(
                CategoryModel.CategoryType.OTHER,
                "أخرى",
                R.drawable.outline_other_admission_24,
                R.color.category_card_bg_other,
                R.color.category_icon_tint_other,
                categoryFilesMap.get(CategoryModel.CategoryType.OTHER).size(),
                categorySizeMap.get(CategoryModel.CategoryType.OTHER),
                categoryFilesMap.get(CategoryModel.CategoryType.OTHER)
        ));

        adapter.notifyDataSetChanged();
    }

    private String formatSize(long size) {
        return android.text.format.Formatter.formatFileSize(this, size);
    }

    private void checkStorageSpace() {
        if (totalSpace > 0 && freeSpace < totalSpace * 0.1) {
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        "space_alert_channel",
                        "تنبيه المساحة المنخفضة",
                        NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("إشعارات لتنبيه المستخدم عند انخفاض المساحة التخزينية.");
                notificationManager.createNotificationChannel(channel);
            }
            Notification notification = new NotificationCompat.Builder(this, "space_alert_channel")
                    .setContentTitle("تنبيه: المساحة ممتلئة!")
                    .setContentText("المساحة المتبقية قليلة. يرجى حذف بعض الملفات لتحسين الأداء.")
                    .setSmallIcon(R.drawable.baseline_warning_24)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .build();
            notificationManager.notify(1, notification);
        }
    }

    private void showCleaningAnimation() {
        runOnUiThread(() -> {
            cleaningAnimation.setVisibility(View.VISIBLE);
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            cleaningAnimation.startAnimation(shake);
            shake.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) { }
                @Override
                public void onAnimationRepeat(Animation animation) { }
                @Override
                public void onAnimationEnd(Animation animation) {
                    cleaningAnimation.setVisibility(View.GONE);
                }
            });
        });
    }
}
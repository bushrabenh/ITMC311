package com.example.smartfileorganizer;


import android.content.Context;
import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.FileViewHolder> {

    private List<File> fileList;
    private Context context;
    private OnFileActionListener listener; // جديد: لإرسال الأحداث إلى النشاط

    // واجهة استماع للأحداث (مثل الحذف)
    public interface OnFileActionListener {
        void onDeleteClick(File file, int position);
    }

    public FileAdapter(Context context, List<File> fileList, OnFileActionListener listener) {
        this.context = context;
        this.fileList = fileList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_file_recommendation, parent, false);
        return new FileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FileViewHolder holder, int position) {
        File file = fileList.get(position);

        holder.fileName.setText(file.getName());
        holder.fileSize.setText("الحجم: " + Formatter.formatFileSize(context, file.length()));
        holder.filePath.setText(file.getParent()); // عرض المسار الأب

        // يمكنك تعيين أيقونات مختلفة بناءً على نوع الملف هنا
        // holder.fileIcon.setImageResource(getFileIcon(file));

        holder.deleteButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(file, holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return fileList.size();
    }

    // لتحديث القائمة بعد الحذف أو أي تغيير
    public void removeFileAt(int position) {
        if (position >= 0 && position < fileList.size()) {
            fileList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, fileList.size()); // تحديث المؤشرات بعد الحذف
        }
    }

    // ViewHolder يحمل الـ Views لكل عنصر
    public static class FileViewHolder extends RecyclerView.ViewHolder {
        ImageView fileIcon;
        TextView fileName;
        TextView fileSize;
        TextView filePath;
        Button deleteButton;

        public FileViewHolder(@NonNull View itemView) {
            super(itemView);
            fileIcon = itemView.findViewById(R.id.fileIcon);
            fileName = itemView.findViewById(R.id.fileName);
            fileSize = itemView.findViewById(R.id.fileSize);
            filePath = itemView.findViewById(R.id.filePath);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    // دالة مساعدة لتعيين أيقونة الملف بناءً على النوع (اختياري)
    /*
    private int getFileIcon(File file) {
        String fileName = file.getName().toLowerCase();
        if (fileName.endsWith(".jpg") || fileName.endsWith(".png") || fileName.endsWith(".gif")) {
            return R.drawable.ic_image_24dp; // تحتاج لإنشاء هذه الأيقونات
        } else if (fileName.endsWith(".mp4") || fileName.endsWith(".avi")) {
            return R.drawable.ic_video_24dp;
        } else if (fileName.endsWith(".pdf") || fileName.endsWith(".doc")) {
            return R.drawable.ic_document_24dp;
        } else if (fileName.endsWith(".apk")) {
            return R.drawable.ic_apk_24dp;
        }
        return R.drawable.ic_file_24dp; // أيقونة عامة
    }
    */
}

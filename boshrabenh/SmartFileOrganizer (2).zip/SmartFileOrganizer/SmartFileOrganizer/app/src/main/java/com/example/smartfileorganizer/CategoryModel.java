package com.example.smartfileorganizer;

import java.io.File;
import java.util.List;

public class CategoryModel {
    public enum CategoryType {
        IMAGE, VIDEO, DOCUMENT, AUDIO, ARCHIVE, APK, OTHER
    }

    private CategoryType type;
    private String title;
    private int iconResId;
    private int cardColorResId;
    private int iconColorResId;
    private int fileCount;
    private long totalSize;
    private List<File> files;

    public CategoryModel(CategoryType type, String title, int iconResId, int cardColorResId, int iconColorResId, int fileCount, long totalSize, List<File> files) {
        this.type = type;
        this.title = title;
        this.iconResId = iconResId;
        this.cardColorResId = cardColorResId;
        this.iconColorResId = iconColorResId;
        this.fileCount = fileCount;
        this.totalSize = totalSize;
        this.files = files;
    }

    public CategoryType getType() { return type; }
    public String getTitle() { return title; }
    public int getIconResId() { return iconResId; }
    public int getCardColorResId() { return cardColorResId; }
    public int getIconColorResId() { return iconColorResId; }
    public int getFileCount() { return fileCount; }
    public long getTotalSize() { return totalSize; }
    public List<File> getFiles() { return files; }
}